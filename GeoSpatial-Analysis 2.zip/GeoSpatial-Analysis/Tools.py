from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from sklearn.neighbors import NearestNeighbors
from math import cos, sin, atan2, sqrt

from shapely.ops import cascaded_union, polygonize
from scipy.spatial import Delaunay
import shapely.geometry as geometry
from sklearn import metrics

import numpy as np
import math


class Operations():
    def __init__(self):
        pass

    def get_sparseNeighbors(self, dataIN, radius=500):
        '''
            input: A matrix/dataFrame (only numerical attributes)
            output: A Sparse matrix with cell value equal to 1 corresponsing to all nearest neighbors
            Function: Finds all the coord_point (nearest neighbors) within a certain radius from each data point
        '''
        neigh = NearestNeighbors(radius=radius)
        neigh.fit(dataIN)
        sparseNeighbors = neigh.radius_neighbors_graph(dataIN)
        return sparseNeighbors  # sparseNeighbors.toarray()

    def standarize(self, dataIN):
        return (dataIN - np.mean(dataIN, axis=0)) / np.std(dataIN, axis=0)

    def haversine_dist(self, origin, destination):
        lat1 = origin[0]
        lon1 = origin[1]
        lat2 = destination[0]
        lon2 = destination[1]
        radius = 6371  # In Kilometer

        # print (lat1,lon1,lat2,lon2)

        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat / 2) * math.sin(dlat / 2) + math.cos(math.radians(lat1)) \
                                                      * math.cos(math.radians(lat2)) * math.sin(dlon / 2) * math.sin(
            dlon / 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        d = radius * c

        return d
    
    def get_mean_stdev_c2_indices(self, dataIN,
                                  mean=False,
                                  stdev=False,
                                  rmv_outliers=False,
                                  num_stdev=2):
        
        if mean and stdev and rmv_outliers:
            m = np.mean(dataIN, axis=0)
            sd = np.std(dataIN, axis=0)
            dataIN_m = dataIN - m
            # The below code catches outliers in both the direction
            outlier_index = np.sort(np.unique(list(np.where(dataIN_m[:, 0] > num_stdev*sd[0])[0]) +
                                              list(np.where(dataIN_m[:, 1] > num_stdev*sd[1])[0]))
                                    )
            points_index = np.ones(dataIN.shape[0], dtype=bool)
            # print ('outlierIndex ',outlier_index)
            
            if any(outlier_index):
                points_index[outlier_index] = False
                
            return m, sd, points_index
        elif mean:
            return np.mean(dataIN, axis=0)
        elif stdev:
            return np.std(dataIN, axis=0)
        else:
            raise ValueError('You should atleast provide one output type')


    def center_geolocation(self, geolocations):
        """
        Provide a relatively accurate center lat, lon returned as a list pair, given
        a list of list pairs.
        ex: in: geolocations = ((lat1,lon1), (lat2,lon2),)
            out: (center_lat, center_lon)
        """
        x = 0
        y = 0
        z = 0
    
        for lat, lon in geolocations:
            lat = float(lat)
            lon = float(lon)
            x += cos(lat) * cos(lon)
            y += cos(lat) * sin(lon)
            z += sin(lat)
    
        x = float(x / len(geolocations))
        y = float(y / len(geolocations))
        z = float(z / len(geolocations))
    
        return (atan2(y, x), atan2(z, sqrt(x * x + y * y)))


class PolygonArea():
    
    def __init__(self):
        pass

    def rmv_duplicate(self, data):
        sorted_data = data[np.lexsort(data.T), :]
        row_mask = np.append([True], np.any(np.diff(sorted_data, axis=0), 1))
        return sorted_data[row_mask]
    
        
    def add_edge(self, coords, i, j):
        """
            Add an edge between two near vertices if not already exists
        """
        if (i, j) in self.edges or (j, i) in self.edges:
            return
        self.edges.add((i, j))
        self.edge_coord_point.append(coords[[i, j]])
        

    def traingle_area(self, coord1, coord2, coord3):
    
        # Calculate the Lengths of sides of triangle (This is simply the euclidean distance)
        side1 = metrics.pairwise.euclidean_distances(coord1.reshape(1, -1), coord2.reshape(1, -1))[0][0]
        
        side2 = metrics.pairwise.euclidean_distances(coord2.reshape(1, -1), coord3.reshape(1, -1))[0][0]
        
        side3 = metrics.pairwise.euclidean_distances(coord3.reshape(1, -1), coord1.reshape(1, -1))[0][0]
    
        # Find Area of triangle by Heron's formula
        #  s = Semiperimeter of triangle, half of the total perimeter
        s = (side1 + side2 + side3) / 2.0

        area = math.sqrt(s * np.abs(s - side1) * np.abs(s - side2) * np.abs(s - side3))
        
        return side1, side2, side3, area


    def alpha_shape(self, coord_point, alpha):
        """
        
        Compute the alpha shape (concave hull) of a set
			of coord_point.
			Inputs: coord_point - The input 2D coord_point
					alpha  - A sort of threshold to trade off between concave Hull and Convex Hull
							The more the value of alpha the more less the area of the polygon connecting coord_point (high order conccave hull)
							The less the value of alpha the less the area of the polygon connection coord_point (Convex hull)
			Output: polygoncoord_point - The polygon coord_point (outer most coord_point)
			extracted based on the input alpha
			
			
		    coord_point to keep note of:
		    
		    Case 1 - There are several cases where input point array (cluster) has more than elements. But they can all be the same point. For example, the array below has 4 elements in the cluster they they are the same coordinate. And we cant find the area of a point.
		         [4850986.51441273   338896.53899243]
                 [4850986.51441273   338896.53899243]
                 [4850986.51441273   338896.53899243]
                 [4850986.51441273   338896.53899243]
            
            Case 2 - Sometimes the count of unique elements in input coord_point can be less than 4. In such a case its either a rectangle, line or a points.
		"""
        self.edges = set()
        self.edge_coord_point = []
        
        # Case 1:
        print ('The shape of actual points are : ', coord_point.shape)
        coord_point = self.rmv_duplicate(coord_point)
        
        print ('The shape of unique points are : ', coord_point.shape)
        
        # Case 2:
        if len(coord_point) < 4:
			# When you have a triangle, there is no sense in computing an alpha shape.
            # We can either call the function below or the "traingle_area" function defined above.
            return geometry.MultiPoint(list(coord_point)).convex_hull.area, []
            
        # Find all the non overlapping triangle
        coords = np.array(coord_point)
        
        # Delaunay will just assign random points
        tri = Delaunay(coords)
        
        for ia, ib, ic in tri.vertices:
            side1, side2, side3, area = self.traingle_area(coords[ia],
                                                           coords[ib],
                                                           coords[ic])
            circum_r = side1 * side2 * side3 / (4.0 * area)
            
            # The more the length of edges the more will be the circumference
            # This step will basically avoid connecting far edges, which are mostly
            #  a result of convex hull. In other words if the coord_point are near to each other
            #  till a certain threshold only then the edges are retained between each vertices.
            if circum_r < 1.0 / alpha:
                self.add_edge(coords, ia, ib)
                self.add_edge(coords, ib, ic)
                self.add_edge(coords, ic, ia)
                
        # edge_coord_point are the coord_point that qualifies the given alpha value. A Edge point
        m = geometry.MultiLineString(self.edge_coord_point)
        triangles = list(polygonize(m))
        
        # Cascade_union will remove all the tringle edge that are not at the exterior
        #  and only keep the once that are the outer most edges as a result of the input alpha.
        #  Hence creating a single polygon which makes it easier to find the area and makes it easier to plot.

        polygon_circum_points = cascaded_union(triangles)
        
        return polygon_circum_points.area, polygon_circum_points