
1. Tuning Parameters:

		minSamples (k) -> num of Nearest Neighbors
		minDistance (eps) -> The Maximum distance between two points
		mdistanceMetric (metric)-> Euclidean, precomputed, Haversine

		single_clusters --> False, True : While performing density Clustering the value "True" would remove all points that are a single cluster (only one point in the cluster) , possible outliers
		how_many = How many Top dense clusters to extract

		alpha --> deafualt = 2.5 (The concave hull alpha shape)


############  Analysis   ##############

Projections:

UTM (Universal Transverse Mercator) -- Best for small area 
One of the biggest advantages of a UTM is that measuring distances between two points is a pretty quick.
Measuring distances between points in latitude and longitude degrees requires something like geodesic
or Haversine which may have pretty heavy math.
UTM divides the earth into 60 zones each of which is about 300-475 miles wide east-to-west, 
depending on what latitude. Inside that zone, and usually into the next zone east or west, measurements are quite accurate. 
But that accuracy fades the farther away from the origin you get. That means you need to know which zone your map area is in, 
and it makes UTM a poor choice for national or world maps that covers a large area.

UTM zone Michagan: 17, T
Check using: utm.from_latlon(44.017185, -83.044312)

Mercetor: EPSG 3857
This is something google map followa to make plots. What ever you see in google maps is EPSG 3857
This is good for Long distance computation such as you would want to find distance between a point 
in Europe and Asia. Then if your distance is off by half a mile or 1 mile, It wont be a problem.

Other important Projections:
US National Atlas equal area: EPSG: 2163
WGS84: EPSG 4326
UTM zone 11N: EPSG:2955



Parameter setting:

minDistance = 0.025	# For projection=False the minDistance should be in kilometers
minSamples = 17
projection = False
numTopClusters = 6
singleClusters = False
alpha = 2.5

hours_btwn = [20,7]
months = []
days = [0, 1, 2, 3,4] # 0-> Monday, 6 -> Sunday


1> Good indices [Under 55 meters of distance]: 99, 109, 252, 425, 222, 105, 80, 62, 77

2> Cant find good cluster, dense points are far away from each other
    754 (28 datapoints), 122 (25 data points), 177 (2 data point), 69 (1 data point), 28 (1 data point), 812 (1 data point)

3> Very weird: No data points near the actual address point
    354, 711, 384

4> No clusrters (clusterNum = -1) 591, 602, 14

5> No data points after filtering


Row Number and device ID:
------------------------------
99 : 1fb38205f38c8af96296c6f91f694a7ec429fafe