import random
import numpy as np
import pandas as pd
import geopandas as gpd
from sklearn import metrics
from Plots import Plot, GeoPlot
import DataGenerator
from Tools import Operations
import utm
from main import dataCleaner, dataBuilder, dataPrep, densityClusterBuilder





def densityPlot(datIN):
    obj_plot = Plot()
    obj_plot.set_figure(2,2, 1200,1500)

    # plot1
    obj_plot.set_config({'plot_type':'scatter', 'plot_mode':'markers', 'plot_name':'scatter_LonLat'})
    obj_plot.base_plot(x=datIN['Longitude'], y=datIN['Latitude'])

    # plot2
    obj_plot.set_config({'plot_type':'scatter', 'plot_mode':'markers', 'plot_name':'scatter_UTM'})
    obj_plot.base_plot(x=datIN['lonUTM'], y=datIN['latUTM'])

    # plot3
    obj_plot.set_config({'plot_type':'scatter', 'plot_mode':'markers', 'plot_name':'histogram2Dcontours-LonLat'})
    obj_plot.base_plot(x=datIN['Longitude'], y=datIN['Latitude'])
    obj_plot.set_config({'plot_type':'hist2Dcontour'})
    obj_plot.add_plot(x=datIN['Longitude'], y=datIN['Latitude'])

    # plot4
    obj_plot.set_config({'plot_type':'scatter', 'plot_mode':'markers', 'plot_name':'histogram2Dcontours-UTM'})
    obj_plot.base_plot(x=datIN['lonUTM'], y=datIN['latUTM'])
    obj_plot.set_config({'plot_type':'hist2Dcontour'})
    obj_plot.add_plot(x=datIN['lonUTM'], y=datIN['latUTM'])
    obj_plot.show(plotFileName='Histogram-2D-contour-Plot')



#################### Cluster Plot
## Plots:
def densityClusterPlot(dataIN, clusterLabelsIN):
	obj_plot = Plot()
	obj_plot.set_figure(1,2, 600,1200)

	# Plot 1
	obj_plot.set_config(dict(plot_type='scatter', plot_mode='markers', plot_name='scatter LatLon'))
	obj_plot.base_plot(x=dataIN[:,0], y=dataIN[:,1])
 
	# Plot 2
	obj_plot.set_config(dict(plot_type='scatter', plot_mode='markers', marker_config=dict(color=clusterLabelsIN, colorscale='Viridis', showscale=True, size=6, opacity=0.6)))
	obj_plot.base_plot(x=dataIN[:,0], y=dataIN[:,1])
	obj_plot.show(plotFileName='Cluster-Plot')



def topClusterPlot(dataIN, topClustersDF_dict, numTopClusters=4):#dataIN, clusterLabels_IN):
    obj_plot = Plot()
    obj_plot.set_figure(int(np.ceil(numTopClusters/2)), 2)
    
    for clusterNum, clusterPoints in topClustersDF_dict.items():
        # Plot 1:
        obj_plot.set_config(dict(plot_type='scatter',
			plot_mode='markers',
			plot_name='cluster'+str(clusterNum),
			marker_config=dict(size=4,opacity=0.3, color='black'))
        )
        
        obj_plot.base_plot(x=dataIN.iloc[:,0],
                           y=dataIN.iloc[:,1])
        
        
        
        obj_plot.set_config(dict(plot_type='scatter',
			plot_mode='markers',
			marker_config=dict(size=4,opacity=0.7, color='red'))
		)
        
        obj_plot.add_plot(x=clusterPoints.iloc[:,0],
                          y=clusterPoints.iloc[:,1])
        
    obj_plot.show(plotFileName='Top Clusters - Plot')



def c1Cluster_Plot(dataIN,
                   topClusterIndices_Dict,
                   actualLocation,# actLatLon,
                   zone = 17,
                   projection=False):  # 17, T corresponds to the zone of Michigan
    
    obj_op = Operations()
    obj_plot = Plot()
    obj_plot.set_figure(int(np.ceil(len(topClusterIndices_Dict.keys())/2)), 2)

    actualLocationUTM = utm.from_latlon(
            actualLocation[0], actualLocation[1]
    )
    
    for clusterNum, cluster_indices in topClusterIndices_Dict.items():
        print ('Running for Cluster ........ ', clusterNum)
        if not projection:
            c1_ClusterPoints = dataIN[cluster_indices, 0:2]

            # The the mean point using UTM projections
            c1_UTM_mean = np.mean(
                    dataIN[cluster_indices, 2:4], axis=0  # 2:4 corresponds to the UTM projection dataPoints
            )
            
            # Convert the Projection back to Lat Lon coordinate system
            c1_ClusterCenter = utm.to_latlon(
                    c1_UTM_mean[0], c1_UTM_mean[1], zone, 'T'
            )

            dist = obj_op.haversine_dist(c1_ClusterCenter, actualLocation)
            print('Haversine Dist b/w mean coordinate of cluster %s and actual coordinate: ' % str(clusterNum), dist)
        else:
            c1_ClusterPoints = dataIN[cluster_indices, 2:4]

            c1_ClusterCenter = np.mean(
                    c1_ClusterPoints, axis=0
            )

            actualLocation = actualLocationUTM
            # print (c1_ClusterCenter)
            # print (np.array([actualLocation[0],actualLocation[1]]))
            dist = metrics.pairwise.euclidean_distances(
                    c1_ClusterCenter.reshape(1,-1),
                    np.array([actualLocation[0],actualLocation[1]]).reshape(1,-1)
            )
            
            print('Euclidean Dist b/w mean coordinate of cluster %s and actual coordinate: ' % str(clusterNum), dist)
            
        obj_plot.set_config(dict(plot_type='scatter',
								 plot_mode='markers',
								 plot_name='cluster points',
								 marker_config=dict(size=4, opacity=0.3, color='blue')))
        
        obj_plot.base_plot(x=c1_ClusterPoints[:,1], y=c1_ClusterPoints[:,0])
        
        obj_plot.set_config(dict(plot_type='scatter',
								  plot_mode='markers',
								  plot_name='Actual points',
								  marker_config=dict(size=6, opacity=0.8, color='red')))
        
        obj_plot.add_plot(x=[actualLocation[1]], y=[actualLocation[0]])
        
        obj_plot.set_config(dict(plot_type='scatter',
								  plot_mode='markers',
								  plot_name='estimated latlon mean',
								  marker_config=dict(size=6, opacity=0.8, color='green')))
        
        obj_plot.add_plot(x=[c1_ClusterCenter[1]], y=[c1_ClusterCenter[0]])

    if not projection:
        obj_plot.show(plotFileName='Estimated_VS_actualPoint_LatLon-Plot')
    else:
        obj_plot.show(plotFileName='Estimated_VS_actualPoint_UTM-Plot')
 
 
#
#
# def c2Cluster_Plot(dataIN,
#                    topClusterIndices_Dict,
#                    c2ClusterIndices_Dict,
#                    actLatLon,
#                    zone = 17,
#                    projection=False# 17, T corresponds to the zone of Michigan
#                   ):
#     # unqCluster = np.unique(clusterInfo[['clusterNum']])
#     obj_plot = Plot()
#     obj_plot.set_figure(int(np.ceil(len(topClusterIndices_Dict.keys()) / 2)), 2)
#
#     for clusterNum, clusterIndices in topClusterIndices_Dict.items():
#         if not projection:
#             c1_ClusterPoints = dataIN[cluster_indices, 0:2]
#             c2_ClusterPoints = dataIN[c2ClusterIndices_Dict[clusterNum],0:2]
#         else:
#             c1_ClusterPoints = dataIN[cluster_indices, 0:2]
#             c2_ClusterPoints = dataIN[c2ClusterIndices_Dict[clusterNum], 0:2]
#
#         c1cluster_latlonPoints = dataIN[clusterIndices,0:2]
#         c2cluster_latlonPoints = dataIN[c2ClusterIndices_Dict[clusterNum],0:2]
#
#         # print ('c1 cluster points: ', topClusterIndices_Dict[clusterNum])
#         # print ('c2 cluster points: ', c2ClusterIndices_Dict[clusterNum])
#
#         # c1_latlonMean = np.mean(clusterPoints, axis=0)
#         # c2_latlonMean = np.mean(c2clusterPoints, axis=0)
#
#
#         c1_latlonUTM_mean = np.mean(dataIN[clusterIndices,2:4], axis=0)
#         c2_latlonUTM_mean = np.mean(dataIN[c2ClusterIndices_Dict[clusterNum],2:4], axis=0)
#
#         # print ('111111111111111 ',c1_latlonUTM_mean)
#         # print('2222222222222 ', c2_latlonUTM_mean)
#         c1_latlon_center = utm.to_latlon(c1_latlonUTM_mean[0], c1_latlonUTM_mean[1], zone, 'T')
#         c2_latlon_center = utm.to_latlon(c2_latlonUTM_mean[0], c2_latlonUTM_mean[1], zone, 'T')
#
#         # print (c1_latlon_center, c2_latlon_center)
#         c1_dist = Operations().haversine_dist(c1_latlon_center, actLatLon)
#         c2_dist = Operations().haversine_dist(c2_latlon_center, actLatLon)
#         print('c2 - Haversine Dist b/w mean coordinate of cluster %s and actual coordinate: ' % str(clusterNum), c2_dist)
#
#         obj_plot.set_config(dict(plot_type='scatter',
#                                  plot_mode='markers',
#                                  plot_name='cluster points',
#                                  marker_config=dict(size=4, opacity=0.3, color='blue')))
#
#         obj_plot.base_plot(x=c1cluster_latlonPoints[:, 1], y=c1cluster_latlonPoints[:, 0])
#
#         obj_plot.set_config(dict(plot_type='scatter',
#                                  plot_mode='markers',
#                                  plot_name='c2 cluster points',
#                                  marker_config=dict(size=6, opacity=0.8, color='yellow')))
#
#         obj_plot.add_plot(x=c2cluster_latlonPoints[:, 1], y=c2cluster_latlonPoints[:, 0])
#
#         obj_plot.set_config(dict(plot_type='scatter',
#                                  plot_mode='markers',
#                                  plot_name='Actual points',
#                                  marker_config=dict(size=6, opacity=0.8, color='red')))
#
#         obj_plot.add_plot(x=[actLatLon[1]], y=[actLatLon[0]])
#
#         obj_plot.set_config(dict(plot_type='scatter',
#                                  plot_mode='markers',
#                                  plot_name='c1-estimated latlon center',
#                                  marker_config=dict(size=6, opacity=0.8, color='green')))
#
#         obj_plot.add_plot(x=[c1_latlon_center[1]], y=[c1_latlon_center[0]])
#
#         obj_plot.set_config(dict(plot_type='scatter',
#                                  plot_mode='markers',
#                                  plot_name='c2-estimated latlon center',
#                                  marker_config=dict(size=6, opacity=0.8, color='black')))
#
#         obj_plot.add_plot(x=[c2_latlon_center[1]], y=[c2_latlon_center[0]])
#
#     obj_plot.show(plotFileName='c2-clusters Mean_coord_VS_actLatLon-Plot')
#
#

def alphaShape_area_plot(dataIN,
                         topClusterIndices_Dict,
                         clusterCirumPoints_dict):
    obj_plot = GeoPlot()
    obj_plot.set_figure(2, 2, 15, 10)

    for clstr_no, indices in topClusterIndices_Dict.items():
        if any(indices):  # != None
            s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
            geo_df = gpd.GeoDataFrame(geometry=s)
        
            obj_plot.set_data(geo_df)
            obj_plot.base_plot()
            obj_plot.add_plot(pd.DataFrame({
                'x': np.array(dataIN.loc[indices, ['lonUTM']]).reshape(1, -1)[0],
                'y': np.array(dataIN.loc[indices, ['latUTM']]).reshape(1, -1)[0]
            }))

    obj_plot.show()

###  Plotting only the polygon outline
# import geopandas as gpd
# from Plots import GeoPlot
# from shapely import geometry
#
#
# obj_plot = GeoPlot()
# obj_plot.set_figure(2,2,15,15)
#
#
# clstr_no = 0
# s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
# geo_df = gpd.GeoDataFrame(geometry=s)
# obj_plot.set_data(geo_df)
# obj_plot.base_plot()
#
#
# indices = topClusterIndices_Dict[clstr_no]
#
# X = np.array(spatialData.loc[indices, ['lonUTM']]).reshape(1, -1)[0]
# Y = np.array(spatialData.loc[indices, ['latUTM']]).reshape(1, -1)[0]
# obj_plot.add_plot(pd.DataFrame({
#     'x': X,
#     'y': Y
# }))
#
#
#
# clstr_no = 2
# s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
# geo_df = gpd.GeoDataFrame(geometry=s)
# obj_plot.set_data(geo_df)
# obj_plot.base_plot()
#
#
# indices = topClusterIndices_Dict[clstr_no]
#
# X = np.array(spatialData.loc[indices, ['lonUTM']]).reshape(1, -1)[0]
# Y = np.array(spatialData.loc[indices, ['latUTM']]).reshape(1, -1)[0]
# obj_plot.add_plot(pd.DataFrame({
#     'x': X,
#     'y': Y
# }))
#
#
# clstr_no = 3
# s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
# geo_df = gpd.GeoDataFrame(geometry=s)
# obj_plot.set_data(geo_df)
# obj_plot.base_plot()
#
#
# indices = topClusterIndices_Dict[clstr_no]
#
# X = np.array(spatialData.loc[indices, ['lonUTM']]).reshape(1, -1)[0]
# Y = np.array(spatialData.loc[indices, ['latUTM']]).reshape(1, -1)[0]
# obj_plot.add_plot(pd.DataFrame({
#     'x': X,
#     'y': Y
# }))
#


#######################

#
# clstr_no = 3
# s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
# geo_df = gpd.GeoDataFrame(geometry=s)
# obj_plot.set_data(geo_df)
# obj_plot.base_plot()
#
#
# indices = topClusterIndices_Dict[clstr_no]
#
# X = np.array(spatialData.loc[indices, ['lonUTM']]).reshape(1, -1)[0]
# Y = np.array(spatialData.loc[indices, ['latUTM']]).reshape(1, -1)[0]
# obj_plot.add_plot(pd.DataFrame({
#     'x': X,
#     'y': Y
# }))