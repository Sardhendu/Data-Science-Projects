from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import itertools
from copy import deepcopy
import numpy as np
import pandas as pd
from collections import defaultdict, OrderedDict

# Clustering Libraries
from sklearn.cluster import DBSCAN


class DBSCAN_Cluters():
    def __init__(self, eps=0.5,         # Maximum distance between two datapoints
                 min_samples=5,         # number of minimum neighbors around the point to be considered as a core point
                 metric='euclidean',    # The distance metric to be used
                 algorithm='auto',      # The datastructure to be used while making search example: ‘auto’, ‘ball_tree’, ‘kd_tree’, ‘brute’
                 leaf_size=30,          # Number of leaves node
                 p=None,                # The power of miskowski metric 1 for L1(norm), 2 for L2(euclidean norm)
                 n_jobs=1):             # If -1 then the number of jobs are considered equal to the number of CPU cores
        '''
             eps -> Maximum distance between two points to be considered in the same neighborhood
             min_samples -> The number of samples in a neighborhood for a point to be considered as a core point.
        '''

        self.metric = metric
        self.dbscan = DBSCAN(eps=eps, min_samples=min_samples,
                             metric=metric, algorithm=algorithm,
                             leaf_size=leaf_size, p=p,
                             n_jobs=n_jobs)

    def set_data(self, dataIN):
        if self.metric == 'precomputed':
            if dataIN.shape[0] != dataIN.shape[1]:
                raise ValueError('Using Precomputed metric, your data %s should be a square matrix'%str(dataIN.shape))

        self.dataIN = dataIN


    def fit(self):
        fitObj = self.dbscan.fit(deepcopy(self.dataIN))


    def fit_predict(self):
        '''
            Fits the DBSCAN model and transforms the data
            (For unsupervised algorithm we apply the predict on the data)
        '''
        clusterLabels = self.dbscan.fit_predict(deepcopy(self.dataIN))
        return clusterLabels


    def cluster_info(self, clusterLabels):
        clst = pd.DataFrame({'clusterNum': clusterLabels, 'count': np.ones(len(clusterLabels), dtype=int)})
        groupByDF = (clst.groupby('clusterNum')
                     .agg({'count': 'sum'})
                     .sort_values('count', ascending=False)
                     .reset_index())
        return groupByDF


    def get_topClusters(self, clusterLabels,
                        cluster_groupByDF=[],
                        numTopClusters=1,
                        singleClusters=False):
        """
            Returns the indices of top clusters,
            Example topClusterIndices_Dict = {"0": [1,3,4,9,15,20,21], "4":[7,2,6,10,12]}
                this means that  0 is the biggest cluster and the coordinate points belonging the the cluster 0 can be
                found by using the indices [1,3,4,9,15,20,21] form main DataFrame
        """
        # Arange the clusters in descending order of their density
        if not any(cluster_groupByDF):
            cluster_groupByDF = self.cluster_info(clusterLabels)

        # Remove the Rows for single clusters
        if not singleClusters:
            cluster_groupByDF = cluster_groupByDF.loc[cluster_groupByDF['clusterNum'] != -1]

        clusterUnqLabels = np.unique(clusterLabels)
        print('\nUnique Clusters Labels are: ', np.unique(clusterUnqLabels))

        if numTopClusters > len(clusterUnqLabels):
            # raise ValueError(
            print ("\nNote : Number of Top Cluster requested = %s, Number of clusters created = %s" % (str(numTopClusters), str(len(clusterUnqLabels))))


        cluster_Num = np.array(cluster_groupByDF['clusterNum'])

        topClusterIndices_Dict = OrderedDict()  # Use OderedDict, because it rememebrs the order data were inserted

        for num, clstr_no in enumerate(cluster_Num):
            # Break when numTopClusters is reached, when clusterUnqLabels are less then send all of them
            if num == numTopClusters:
                break
            indices = np.where(clusterLabels == clstr_no)[0]
            topClusterIndices_Dict[clstr_no] = indices

        return topClusterIndices_Dict



# X = np.array([[19.111841,   72.910729],
# [19.111342,   72.908387],
# [19.111342,   72.908387],
# [19.137815,   72.914085],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.120217,   72.907121],
# [19.120217,   72.907121],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.111860,   72.911346],
# [19.111860,   72.911346],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.137815,   72.914085],
# [19.115380,   72.909144],
# [19.115380,   72.909144],
# [19.116168,   72.909573],
# [19.119677,   72.905081],
# [19.137815,   72.914085],
# [19.137815,   72.914085],
# [19.112955,   72.910102],
# [19.112955,   72.910102],
# [19.112955,   72.910102],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.115380,   72.909144],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.111860,   72.911346],
# [19.111841,   72.910729],
# [19.131674,   72.918510],
# [19.119677,   72.905081],
# [19.111860,   72.911346],
# [19.111860,   72.911346],
# [19.111841,   72.910729],
# [19.111841,   72.910729],
# [19.111841,   72.910729],
# [19.115380,   72.909144],
# [19.116625,   72.909185],
# [19.115671,   72.908985],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.119677,   72.905081],
# [19.116183,   72.909646],
# [19.113827,   72.893833],
# [19.119677,   72.905081],
# [19.114100,   72.894985],
# [19.107491,   72.901760],
# [19.119677,   72.905081]], dtype='float64')
#
# X = pd.DataFrame(X)
# X.columns = ['Latitude', 'Longitude']
# print (X.head())
#
#
#
# from scipy.spatial.distance import pdist, squareform
# from sklearn.cluster import DBSCAN
# import matplotlib.pylab as plt
# from Tools import Operations
#
# Xcpy = X
# distance_matrix = squareform(pdist(Xcpy, (lambda u,v: Operations().haversine_dist(u,v))))
# print (distance_matrix.shape)
#
# db = DBSCAN_Cluters(eps=0.2, min_samples=5, metric='precomputed')  # using "precomputed" as recommended by @Anony-Mousse
# db.set_data(Xcpy)
# y_db = db.fit_predict()
#
# print (y_db)
# Xcpy['cluster'] = y_db
# Xcpy
#
# plt.scatter(Xcpy['Latitude'], Xcpy['Longitude'], c=Xcpy['cluster'])
# plt.show()