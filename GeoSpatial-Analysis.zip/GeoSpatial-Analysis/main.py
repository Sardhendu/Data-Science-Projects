import pandas as pd
import numpy as np
from datetime import datetime
from collections import OrderedDict
from scipy.spatial.distance import pdist, squareform

# Packages:
from SpatialHandlers import SpatialHandler
from Tools import Operations, PolygonArea
from Clusters import DBSCAN_Cluters



#################### Data Filter

def dataFilter(dataIN, hours=[], month=[], weekdays=[]):
	activeIndices = []
	for num, ts in enumerate(np.array(dataIN.loc[:, ['timeStamp']])):
		# print(num, ts)
		dt = datetime.strptime(ts[0], "%Y-%m-%d %H:%M")
		dtt = dt.timetuple()

		if not any(month):
			month = np.arange(12) + 1  # Here 12 accounts for the total

		if not any(weekdays):  # Here 7 corresponds to sun(0) -sat(1)
			weekdays = np.arange(7)

		if (dtt.tm_hour >= hours[0] or dtt.tm_hour < hours[1]) and (dtt.tm_mon in month) and (dtt.tm_wday in weekdays):
			activeIndices.append(num)

	return dataIN.loc[activeIndices,:]



#################### Data Cleaner

def dataCleaner(dataIN):
    # Quickly loop through the entire dataset and remove bad entries.
    '''
    	Input: A data frame with atleast two columns
    		1> Latitude and
    		2> Longitude
        Output: A data frame with
        	1> Every input column but clean rows
        	2> A new index column that is the row number of the actual input data set

        1. Remove entries with latitue or longitude values as 0
        2. Remove entries with latitude or longitude that have 3 or less than three decimal points, because they will not add much knowledge to pin pointing the location

        Note: To Confirm
        42.737000 is treated as 42.737 and since 42.737 has only three digits after the decimal points, this is removed form the list
    '''
    # dataIN_copy = dataIN.copy(deep=True)
    badDataIndex = [index
					  for index, lat, lon
					  in zip(dataIN['index'], dataIN['Latitude'], dataIN['Longitude'])
					  if lat == 0
					  or lon == 0
					  or str(lat)[::-1].find('.') <= 3
					  or str(lon)[::-1].find('.') <= 3]

    # print('Indices that do not meet the location requirements are: ', badDataIndices)

    if len(badDataIndex) != len(set(badDataIndex)):
        raise ValueError('Few Indices repeat multiple times')


    cleanedData = dataIN.loc[~dataIN['index'].isin(badDataIndex)]

    if len(cleanedData) + len(badDataIndex) != len(dataIN):
        raise ValueError('The length of badData  '
						 +'and Clean data '
						 +'should equal the length of total input data '
						 ,(str(len(badDataIndex)),
						   str(len(cleanedData)),
						   str(len(dataIN))))

    return cleanedData


#################### Initial Dataset Builder and Data Preparer

def dataBuilder(dataIN):
	'''
		Input: A data frame with atleast two columns
			1> Latitude and
			2> Longitude
		Output: A data frame with
			1> Every input column including the index column
			2> If specified 'lonUTM' and 'latUTM
			3> If specified Geometric Lat Lon points
			4> If specified Geometric Mercetor points
	'''

    # # Spatial Handler
	objSpHandler = SpatialHandler()
	objSpHandler.set_data(dataIN)
	kwargs = {'to_UTM': True}#, 'to_GeoPoints': ['UTM', 'LonLat']}
	(utmProj, geomPoints_UTM, geomPoints_LonLat) = objSpHandler.transform_toUTM('Longitude', 'Latitude', **kwargs)

    # Now we add the columns to the DataFrame
	dataIN['latUTM'] = utmProj[:, 1]
	dataIN['lonUTM'] = utmProj[:, 0]
    # dataIN['geometryUTM'] = geomPoints_UTM
    # dataIN['geometryLonLat'] = geomPoints_LonLat

    ############
    # The below produces error because some of the latitude and longitude points becomes high degree of floating point such as POINT (-84.40524000000001 42.770348). Hence we have to handle this scenario
    ############
    # We would also like to add a colum with a different Mercetor projection
    # objSpHandler.set_data(dataIN)
    # geomPointsMerc = objSpHandler.transform_toMerc(column_LonLat='geometryLonLat',
    # 												dataIN=dataIN,
    # 												epsg=3857
    # 											)
    # dataIN['geometryMerc'] = geomPointsMerc
	return dataIN



# Prepare DataSet
def dataPrep(dataIN, sparseNeighbor=False):
    dataOUT = np.array(dataIN[['latUTM', 'lonUTM']])  # [[0,0], [2,0], [0,2]]#[[0., 0., 0.], [0., .5, 0.], [1., 1., .5]]
    dataOUT = Operations().standarize(np.array(dataIN[['latUTM', 'lonUTM']]))
    
    dataIN['latUTM_sc'] = dataOUT[:,1]
    dataIN['lonUTM_sc'] = dataOUT[:,0]
    
    # Calculating sparse neighbors, This preprocessing would help us to reduce 1 on 1 compare later with the density algorithm
    if sparseNeighbor:
        dataOUT = Operations().get_sparseNeighbors(dataOUT)
    
    # We would like to print the number of neighbors for some random samples
    #  randNUM = np.random.randint(0,300,50)
    #  print (np.sum(sparseNeighbors[randNUM].toarray(), axis=1))
    
    return dataIN


###################### Clustering with DBSCAN
###################### Find Top Clusters (Individual Clusters)
def densityClusterBuilder(dataIN, eps, minSamples,
                          projection=True,
                          distanceMetric='euclidean',
                          numTopClusters=None,
                          singleClusters=False):
    '''
        Input:
            1. dataIN: The Scaled Data.
            2. numTopClusters: retrieve at most how many top clusters
        Output:
            1. clusterLabels : A list containing the label of each data set assigned to the cluster number
            2. cluster_groupByDF: A data frame consisting the cluster number and the count of elements in that cluster
            3. topClusterIndices_Dict : A dictionary containing the top most dense clusters and all the elements in it This output is only used for analysis, hence the default operation will not gather this data, unless specified by the user.
    '''
    ## Clustering:
    if not projection:
        distMatrix = squareform(pdist(dataIN, (lambda u, v: Operations().haversine_dist(u, v))))
        objDBSCAN = DBSCAN_Cluters(eps=eps, min_samples=minSamples, metric=distanceMetric)
        objDBSCAN.set_data(distMatrix)
    else:
        objDBSCAN = DBSCAN_Cluters(eps=eps, min_samples=minSamples, metric=distanceMetric)
        objDBSCAN.set_data(dataIN)
        
    clusterLabels = objDBSCAN.fit_predict()
    print (clusterLabels)

    ## Analysis:
    cluster_groupByDF = objDBSCAN.cluster_info(clusterLabels)
    

    if numTopClusters != None:
        topClusterIndices_Dict = objDBSCAN.get_topClusters(
                clusterLabels=clusterLabels,
                numTopClusters=numTopClusters,
                singleClusters=singleClusters)
        return clusterLabels, cluster_groupByDF, topClusterIndices_Dict
    else:
        return clusterLabels, cluster_groupByDF




def getCluster_Area(dataIN, topClusterIndices_Dict, alpha, projection):
    '''
        :param dataIN: The input data points whose area to find
        :param topClusterIndices_Dict: Keys (cluster num) and values (indices of cluster points)
        :param alpha: the concave hull parameter
        :param projection: If projection is True then the data is already converted into UTM. If the projection is false then we need to find the UTM projection of the input latlon data and then find the area of the polygon.
        
        :return: The clusrter area
    '''

    # objSp = SpatialHandler()
    # if not projection:
    #     dataIN = np.array([objSp.latlon_toUTM(lon, lat)
    #                         for lon, lat in zip(dataIN[:, 1], dataIN[:, 0])])
    
    clusterArea = OrderedDict()
    clusterCirumPoints = OrderedDict()
    objPolygon = PolygonArea()
    
    for cluster_num, cluster_indices in topClusterIndices_Dict.items():
        print ('Running for cluster....... ', cluster_num, 'data point shape ', dataIN[cluster_indices, :].shape)
        (clusterArea[cluster_num], clusterCirumPoints[cluster_num]) = \
			objPolygon.alpha_shape(dataIN[cluster_indices, :], alpha=alpha)
            
    return clusterArea, clusterCirumPoints



def meanVSactual_dist(dataIN, topClusterIndices_Dict, actLatLon):
	'''
		:param topClusterIndices_Dict (DataFrame): The information abou the cluster formed, such as cluster number and corresponding latitude and Longitude points
		:param actLatLon: (numpy array): The actual location (latitude and longitude) of the runing device
		:return meanDist(OrderedDict); Outputs the cluster number as the key and the haversine distance between the mean lat lon of the cluster and the actual lat lon of the device
	'''
	meanDist = OrderedDict()
	for cluster_num, cluster_indices in topClusterIndices_Dict.items():
		clusterPoints = dataIN[cluster_indices, :]
		latlonMean = np.mean(clusterPoints, axis=0)
		dist = Operations().haversine_dist(latlonMean, actLatLon)
		# print('Haversine Dist b/w mean coord of cluster %s and actual coord: ' % str(clusterNum), dist)
		meanDist[cluster_num] = dist
	return meanDist


def getCluster_Info(spatialData, topClusterIndices_Dict):
	'''
		:param spatialData (Data Frame): This is equivalent to the actual data files, the difference being that it contains additional spatial column.
		:param topClusterIndices_Dict (OrderedDict): It contains the cluster number as its key in the ascending order of decreasing density and the value here is the indexes of the datapoints that are the part of the corresponding cluster
		:return: (DataFrame): The information about the cluster formed, such as cluster number and corresponding latitude and Longitude points
	'''
	clusterInfo = pd.DataFrame(columns=['index', 'deviceID', 'Latitude', 'Longitude', 'clusterNum'])
	for clusterNum, tc_indices in topClusterIndices_Dict.items():
		data = spatialData.loc[tc_indices][['index', 'deviceID', 'Latitude', 'Longitude']]
		data['clusterNum'] = np.array([clusterNum for i in np.arange(len(tc_indices))])
		clusterInfo = pd.concat([clusterInfo, data]).reindex()
	return clusterInfo
