import random
import numpy as np
import pandas as pd
from Plots import Plot
import DataGenerator
from main import dataCleaner, dataBuilder, dataPrep, densityClusterBuilder, getCluster_Info
from mainPlots import densityPlot, densityClusterPlot, topClusterPlot, meanVSactual_dist_plot


#############################  Global Declaration  #############################
minDistance = 0.005
minSamples = 17
distanceMetric = 'euclidean'
how_many = 2
singleClusters = False
alpha = 2.5

deviceID = None
indexNum=99      #
num_rand_data=1
#################################################################################


density_plot = True
cluster_plot = True
top_cluster_plot = True
meanVSact_dist_plot = True


## Generate the data set (The true data set and the train/test dataset)
deviceLocationData = DataGenerator.generateData(indexNum=indexNum)
actDeviceLocation = DataGenerator.generateTruthData(indexNum=indexNum)


## Clean the data set
cleanData = dataCleaner(deviceLocationData).reset_index()


## Get the spatial points
if density_plot:
	spatialData = dataBuilder(cleanData)
	densityPlot(spatialData)


## Scale the dataset and find Clusters
if density_plot and cluster_plot:
	# print (chicagoCrime.head())
	dataUTM_scaled = dataPrep(spatialData, sparseNeighbor=False)
	# clusterLabels, cluster_groupByDF, topClusterIndices_Dict = densityClusterBuilder(dataUTM_scaled, how_many=how_many)

	(clusterLabels,
	 cluster_groupByDF,
	 topClusterIndices_Dict) = densityClusterBuilder(dataIN=dataUTM_scaled,
													 eps=minDistance,
													 minSamples=minSamples,
													 distanceMetric=distanceMetric,
													 how_many=how_many,
													 singleClusters=singleClusters)

	print ('The cluster labels are given a: ', clusterLabels)
	print ('Top Clusters grouped by are: ', cluster_groupByDF)

	# Plot the cluster density plot
	densityClusterPlot(dataUTM_scaled, clusterLabels)

	## Add the cluster column to the dataframe:
	chicagoCrimeNew = spatialData[['lonUTM','latUTM']]
	chicagoCrimeNew['clusterNo'] = clusterLabels

	if top_cluster_plot:
		list_of_topClustersDF = []

		for num, (key, value) in enumerate(topClusterIndices_Dict.items()):
			list_of_topClustersDF.append(chicagoCrimeNew.iloc[topClusterIndices_Dict[key],:])
			if num+1 == how_many: break
		topClusterPlot(chicagoCrimeNew, list_of_topClustersDF, how_many=how_many)


## Find the cluster centroid with the original data points
if density_plot and cluster_plot and meanVSact_dist_plot:
	clusterInfo = getCluster_Info(spatialData, topClusterIndices_Dict)
	meanVSactual_dist_plot(clusterInfo, actLatLon=np.array(actDeviceLocation[['Latitude', 'Longitude']])[0])


## Get the area
# #### Get Each Cluster Area
	#  clusterArea = getCluster_Area(dataIN=dataUTM_scaled,
	#  						topClusterIndices_Dict=topClusterIndices_Dict,
	#  						alpha = apha
	#  					)

    # cluster_groupByDF['ClusterArea'] = clusterArea.values()

    # print (cluster_groupByDF)