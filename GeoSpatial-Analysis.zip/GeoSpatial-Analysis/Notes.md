
1. Tuning Parameters:

		minSamples (k) -> num of Nearest Neighbors
		minDistance (eps) -> The Maximum distance between two points
		mdistanceMetric (metric)-> Euclidean, precomputed, Haversine

		single_clusters --> False, True : While performing density Clustering the value "True" would remove all points that are a single cluster (only one point in the cluster) , possible outliers
		how_many = How many Top dense clusters to extract

		alpha --> deafualt = 2.5 (The concave hull alpha shape)


############  Analysis   ##############

Parameter setting:

minDistance = 0.025	# For projection=False the minDistance should be in kilometers
minSamples = 17
projection = False
numTopClusters = 6
singleClusters = False
alpha = 2.5

hours_btwn = [20,7]
months = []
days = [0, 1, 2, 3,4] # 0-> Monday, 6 -> Sunday


1> Good indices [Under 55 meters of distance]: 99, 109, 252, 425, 222, 105, 80, 62, 77

2> Cant find good cluster, dense points are far away from each other
    754 (28 datapoints), 122 (25 data points), 177 (2 data point), 69 (1 data point), 28 (1 data point), 812 (1 data point)

3> Very weird: No data points near the actual address point
    354, 711, 384

4> No clusrters (clusterNum = -1) 591, 602, 14

5> No data points after filtering