import random
import numpy as np
import pandas as pd
import geopandas as gpd
from Plots import Plot, GeoPlot
import DataGenerator
from Tools import Operations
from main import dataCleaner, dataBuilder, dataPrep, densityClusterBuilder





def densityPlot(datIN):
    obj_plot = Plot()
    obj_plot.set_figure(2,2, 1200,1500)

    # plot1
    obj_plot.set_config({'plot_type':'scatter', 'plot_mode':'markers', 'plot_name':'scatter_LonLat'})
    obj_plot.base_plot(x=datIN['Longitude'], y=datIN['Latitude'])

    # plot2
    obj_plot.set_config({'plot_type':'scatter', 'plot_mode':'markers', 'plot_name':'scatter_UTM'})
    obj_plot.base_plot(x=datIN['lonUTM'], y=datIN['latUTM'])

    # plot3
    obj_plot.set_config({'plot_type':'scatter', 'plot_mode':'markers', 'plot_name':'histogram2Dcontours-LonLat'})
    obj_plot.base_plot(x=datIN['Longitude'], y=datIN['Latitude'])
    obj_plot.set_config({'plot_type':'hist2Dcontour'})
    obj_plot.add_plot(x=datIN['Longitude'], y=datIN['Latitude'])

    # plot4
    obj_plot.set_config({'plot_type':'scatter', 'plot_mode':'markers', 'plot_name':'histogram2Dcontours-UTM'})
    obj_plot.base_plot(x=datIN['lonUTM'], y=datIN['latUTM'])
    obj_plot.set_config({'plot_type':'hist2Dcontour'})
    obj_plot.add_plot(x=datIN['lonUTM'], y=datIN['latUTM'])
    obj_plot.show(plotFileName='Histogram-2D-contour-Plot')



#################### Cluster Plot
## Plots:
def densityClusterPlot(dataIN, clusterLabelsIN):
	obj_plot = Plot()
	obj_plot.set_figure(1,2, 600,1200)

	# Plot 1
	obj_plot.set_config(dict(plot_type='scatter', plot_mode='markers', plot_name='scatter LatLon'))
	obj_plot.base_plot(x=dataIN[:,0], y=dataIN[:,1])
 
	# Plot 2
	obj_plot.set_config(dict(plot_type='scatter', plot_mode='markers', marker_config=dict(color=clusterLabelsIN, colorscale='Viridis', showscale=True, size=6, opacity=0.6)))
	obj_plot.base_plot(x=dataIN[:,0], y=dataIN[:,1])
	obj_plot.show(plotFileName='Cluster-Plot')



def topClusterPlot(dataIN, topClustersDF_dict, numTopClusters=4):#dataIN, clusterLabels_IN):
    obj_plot = Plot()
    obj_plot.set_figure(int(np.ceil(numTopClusters/2)), 2)
    
    for clusterNum, clusterPoints in topClustersDF_dict.items():
        # Plot 1:
        obj_plot.set_config(dict(plot_type='scatter',
			plot_mode='markers',
			plot_name='cluster'+str(clusterNum),
			marker_config=dict(size=4,opacity=0.3, color='black'))
        )
        
        obj_plot.base_plot(x=dataIN.iloc[:,0],
                           y=dataIN.iloc[:,1])
        
        
        
        obj_plot.set_config(dict(plot_type='scatter',
			plot_mode='markers',
			marker_config=dict(size=4,opacity=0.7, color='red'))
		)
        
        obj_plot.add_plot(x=clusterPoints.iloc[:,0],
                          y=clusterPoints.iloc[:,1])
        
    obj_plot.show(plotFileName='Top Clusters - Plot')



def meanVSactual_dist_plot(topClustersDF_dict, actLatLon):
	# unqCluster = np.unique(clusterInfo[['clusterNum']])
	obj_plot = Plot()
	obj_plot.set_figure(int(np.ceil(len(topClustersDF_dict.keys())/2)), 2)

	for clusterNum, clusterPoints in topClustersDF_dict.items():
		clusterPoints = np.array(clusterPoints[['Latitude', 'Longitude']])

		latlonMean = np.mean(clusterPoints, axis=0)
		dist = Operations().haversine_dist(latlonMean, actLatLon)
		print ('Haversine Dist b/w mean coordinate of cluster %s and actual coordinate: '%str(clusterNum), dist)

		obj_plot.set_config(dict(plot_type='scatter',
								 plot_mode='markers',
								 plot_name='cluster points',
								 marker_config=dict(size=4, opacity=0.3, color='blue')))

		obj_plot.base_plot(x=clusterPoints[:,1], y=clusterPoints[:,0])

		obj_plot.set_config(dict(plot_type='scatter',
								  plot_mode='markers',
								  plot_name='Actual points',
								  marker_config=dict(size=6, opacity=0.8, color='red')))

		obj_plot.add_plot(x=[actLatLon[1]], y=[actLatLon[0]])

		obj_plot.set_config(dict(plot_type='scatter',
								  plot_mode='markers',
								  plot_name='estimated latlon mean',
								  marker_config=dict(size=6, opacity=0.8, color='green')))

		obj_plot.add_plot(x=[latlonMean[1]], y=[latlonMean[0]])

	obj_plot.show(plotFileName='Mean_coord_VS_actLatLon-Plot')



def alphaShape_area_plot(dataIN,
                         topClusterIndices_Dict,
                         clusterCirumPoints_dict):
    obj_plot = GeoPlot()
    obj_plot.set_figure(2,2,15,10)

    for clstr_no, indices in topClusterIndices_Dict.items():
        if any(indices):# != None
            s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
            geo_df = gpd.GeoDataFrame(geometry=s)
            
            obj_plot.set_data(geo_df)
            obj_plot.base_plot()
            obj_plot.add_plot(pd.DataFrame({
                'x': np.array(dataIN.loc[indices, ['lonUTM']]).reshape(1, -1)[0],
                'y': np.array(dataIN.loc[indices, ['latUTM']]).reshape(1, -1)[0]
        }))
        
    obj_plot.show()


###  Plotting only the polygon outline
# import geopandas as gpd
# from Plots import GeoPlot
# from shapely import geometry
#
#
# obj_plot = GeoPlot()
# obj_plot.set_figure(2,2,15,15)
#
#
# clstr_no = 0
# s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
# geo_df = gpd.GeoDataFrame(geometry=s)
# obj_plot.set_data(geo_df)
# obj_plot.base_plot()
#
#
# indices = topClusterIndices_Dict[clstr_no]
#
# X = np.array(spatialData.loc[indices, ['lonUTM']]).reshape(1, -1)[0]
# Y = np.array(spatialData.loc[indices, ['latUTM']]).reshape(1, -1)[0]
# obj_plot.add_plot(pd.DataFrame({
#     'x': X,
#     'y': Y
# }))
#
#
#
# clstr_no = 2
# s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
# geo_df = gpd.GeoDataFrame(geometry=s)
# obj_plot.set_data(geo_df)
# obj_plot.base_plot()
#
#
# indices = topClusterIndices_Dict[clstr_no]
#
# X = np.array(spatialData.loc[indices, ['lonUTM']]).reshape(1, -1)[0]
# Y = np.array(spatialData.loc[indices, ['latUTM']]).reshape(1, -1)[0]
# obj_plot.add_plot(pd.DataFrame({
#     'x': X,
#     'y': Y
# }))
#
#
# clstr_no = 3
# s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
# geo_df = gpd.GeoDataFrame(geometry=s)
# obj_plot.set_data(geo_df)
# obj_plot.base_plot()
#
#
# indices = topClusterIndices_Dict[clstr_no]
#
# X = np.array(spatialData.loc[indices, ['lonUTM']]).reshape(1, -1)[0]
# Y = np.array(spatialData.loc[indices, ['latUTM']]).reshape(1, -1)[0]
# obj_plot.add_plot(pd.DataFrame({
#     'x': X,
#     'y': Y
# }))
#


#######################

#
# clstr_no = 3
# s = gpd.GeoSeries(clusterCirumPoints_dict[clstr_no])
# geo_df = gpd.GeoDataFrame(geometry=s)
# obj_plot.set_data(geo_df)
# obj_plot.base_plot()
#
#
# indices = topClusterIndices_Dict[clstr_no]
#
# X = np.array(spatialData.loc[indices, ['lonUTM']]).reshape(1, -1)[0]
# Y = np.array(spatialData.loc[indices, ['latUTM']]).reshape(1, -1)[0]
# obj_plot.add_plot(pd.DataFrame({
#     'x': X,
#     'y': Y
# }))