from __future__ import division
from __future__ import print_function

import json
import random
import numpy as np
import pandas as pd
import geopandas as gpd
from collections import OrderedDict

from Tools import Operations
import DataGenerator

from main import dataCleaner, dataBuilder, dataPrep, densityClusterBuilder, getCluster_Area, getCluster_Info, meanVSactual_dist, dataFilter

from mainPlots import densityPlot, densityClusterPlot, topClusterPlot, meanVSactual_dist_plot, alphaShape_area_plot


######################################################
# -------------  GLOBAL VARIABLES  ------------------#
######################################################

minDistance = 0.025			# For projection=False the minDistance should be in kilometers
minSamples = 17				# How many neighbors
projection = False			# True using UTM projected distance for the clustering
numTopClusters = 6			# How many top clusters
singleClusters = False		# True to capture outliers in a single clusters
alpha = 0.01# 0.05 				# Parameter to get the best

hours_btwn = [20,7]
months = []
days = [0, 1, 2, 3,4] # 0-> Monday, 6 -> Sunday


deviceID = None
indexNum=77
num_rand_data=1


if projection:
	distanceMetric = 'euclidean'
else:
	distanceMetric = 'precomputed'

__main__ = True
__analysis__ = True
__plot__ = True





######################################################
# ---------------  MAIN CALL  -----------------------#
######################################################


if __main__:
    
    #### Generate Data
    deviceLocationData = DataGenerator.generateData(indexNum=indexNum)
    deviceLocationData = deviceLocationData.reset_index()
    actDeviceLocation = DataGenerator.generateTruthData(indexNum=indexNum)
    
    print('\nMain: The actual data %s looks like \n' % str(deviceLocationData.shape), deviceLocationData.head())
    
    
    #### Filter Data based on time, week days and month (if needed)
    deviceLocationData = dataFilter(dataIN=deviceLocationData,
									hours=hours_btwn,
									month=months,
									weekdays=days)
    
    print('\nMain: The Filtered data %s looks like \n' % str(deviceLocationData.shape), deviceLocationData.head())
    
    #### DATA CLEANER
    cleanData = dataCleaner(deviceLocationData).reset_index()
    cleanData = cleanData.drop('level_0', 1)
    print ('\nMain: The clean data %s looks like \n'%str(cleanData.shape), cleanData.head())
    
    
    #### DATA BUILDER : Get the UTM/Mercetor projection of Latitude and Longitude
    spatialData = dataBuilder(cleanData)
    print ('\nMain: The Spatial Converted data %s looks like \n'%str(spatialData.shape), spatialData.head())
    
    
    #### DATA PREPARER:  Get the scaled data for UTM projection
    spatialData = dataPrep(spatialData, sparseNeighbor=False)
    print('\nMain: The Scaled Data %s looks like \n'%str(spatialData.shape), spatialData.head())


    #### DENSITY CLUSTERING
    (clusterLabels,
     cluster_groupByDF,
     topClusterIndices_Dict) = \
        densityClusterBuilder(dataIN=np.array(spatialData[['Latitude', 'Longitude']]),
                              eps=minDistance,
                              minSamples=minSamples,
                              projection=projection,
                              distanceMetric=distanceMetric,
                              numTopClusters=numTopClusters,
                              singleClusters=singleClusters)

    print ('\nMain: The Top Clusters keys are\n', topClusterIndices_Dict.keys())



	#### Select only the top clusters, Remove singleClusters if asked
    topClusterSummary = cluster_groupByDF.iloc[0:numTopClusters, :]
    print('\nMain: The brief summary of top clusters is:\n', cluster_groupByDF)
    mainClusterSummary = \
        cluster_groupByDF[cluster_groupByDF['clusterNum'].isin(topClusterIndices_Dict.keys())]

    print('\nMain: The main summary of top clusters is:\n', mainClusterSummary)


    ### Get Each Cluster Area, The area is computed using the UTM projection
    clusterArea_dict, clusterCirumPoints_dict = \
        getCluster_Area(dataIN=np.array(spatialData[['lonUTM','latUTM']]),
                        topClusterIndices_Dict=topClusterIndices_Dict,
                        alpha = alpha,
                        projection = projection)


    mainClusterSummary['ClusterArea'] = clusterArea_dict.values()
    print('\nMain: The main Cluster summary of top clusters is:\n', mainClusterSummary)





######################################################
# ---------------  ANALYSIS  ------------------------#
######################################################


if __analysis__:
    clusterSummary = mainClusterSummary
    #### Get Cluster Info - Detailed
    #  Create a data frame that contains the cluster number and its details stashed in a data frame
    clusterInfo = getCluster_Info(spatialData, topClusterIndices_Dict)
    print('\nAnalysis: The Cluster Info %s looks like \n' % str(clusterInfo.shape), clusterInfo.head())
    
    
    #### Get Cluster Info - Detailed
    meanDist1 = meanVSactual_dist(
            dataIN=np.array(spatialData[['Latitude', 'Longitude']]),
            topClusterIndices_Dict=topClusterIndices_Dict,
            actLatLon=np.array(actDeviceLocation[['Latitude', 'Longitude']])[0]
    )
    clusterSummary['meanDist'] = meanDist1.values()
    print ('\nAnalysis: The brief summary of top clusters is:\n', clusterSummary)




######################################################
# -----------------  PLOT  --------------------------#
######################################################

if __plot__:
    ### Get the Density plot using spatial Data:
    # if projection:
    densityPlot(spatialData)

    if clusterInfo.shape[0] >= 1:

        ### Cluster Density Plot:
        densityClusterPlot(np.array(spatialData[['Longitude', 'Latitude']]), clusterLabels)


        #### Top CLuster Plots:
        if projection:
            spatialDataNew = spatialData[['lonUTM', 'latUTM']]
        else:
            spatialDataNew = spatialData[['Longitude', 'Latitude']]

        spatialDataNew['clusterNo'] = clusterLabels
        topClustersDF_dict = OrderedDict()

        for num, (clusterNum, indices) in enumerate(topClusterIndices_Dict.items()):
            topClustersDF_dict[clusterNum] = \
                spatialDataNew.iloc[indices, :]

            if num + 1 == numTopClusters: break

        topClusterPlot(spatialDataNew,
                       topClustersDF_dict,
                       numTopClusters=numTopClusters)


        ### Cluster Mean Vs the actual location plot
        meanVSactual_dist_plot(topClustersDF_dict,
                               actLatLon=np.array(actDeviceLocation[['Latitude', 'Longitude']])[0])

        
        ### Cluster Concave Hull Plot
        alphaShape_area_plot(spatialData, topClusterIndices_Dict,clusterCirumPoints_dict)
    
#
# from shapely import geometry
# polygon_arr = []
# for clstrNo, shape in clusterCirumPoints_dict.items():
#     if (isinstance(shape, geometry.multipolygon.MultiPolygon)):
#         for polygon in shape:
#             polygon_arr.append(polygon)
#         polygon_arr.append(polygon)
#
#
# if (isinstance(clusterCirumPoints_dict[2], geometry.multipolygon.MultiPolygon)):
#     for i in clusterCirumPoints_dict[2]:
#         print (i)
#         print ('qwertyuiortyuio')
